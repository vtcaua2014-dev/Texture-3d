import UIKit
import CoreText

struct AppFont: Identifiable, Hashable {
    let id: String      // PostScript name
    let title: String
}

enum FontLoader {
    // Registra todos os .ttf da pasta Fonts e devolve os nomes PostScript
    static func loadAll() -> [AppFont] {
        var result: [AppFont] = []
        let urls = (Bundle.main.urls(forResourcesWithExtension: "ttf", subdirectory: nil) ?? [])
            .sorted { $0.lastPathComponent < $1.lastPathComponent }
        for url in urls {
            CTFontManagerRegisterFontsForURL(url as CFURL, .process, nil)
            if let provider = CGDataProvider(url: url as CFURL),
               let cg = CGFont(provider),
               let ps = cg.postScriptName as String? {
                let title = url.deletingPathExtension().lastPathComponent
                    .replacingOccurrences(of: "_", with: " ")
                result.append(AppFont(id: ps, title: title))
            }
        }
        return result
    }
}
